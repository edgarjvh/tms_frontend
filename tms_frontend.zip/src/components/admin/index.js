export { default as CompanySetup } from './company-setup/CompanySetup';
export { default as AdminHome } from './admin-home/AdminHome';
