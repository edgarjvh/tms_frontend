export { default as CompanySetup } from './company-setup/CompanySetup';
