import React from 'react';
import { connect } from 'react-redux';
import './CompanyHome.css';

const CompanyHome = (props) => {
    return (
        <div>
            
        </div>
    )
}

export default connect(null, null)(CompanyHome)
